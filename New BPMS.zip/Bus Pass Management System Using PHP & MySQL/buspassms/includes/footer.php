
	<div class="copy-right"> 
		<div class="container">
			<p>© 2021 Bus Pass Management System</p>
		</div> 
	</div> 
	<!-- //footer -->   
	